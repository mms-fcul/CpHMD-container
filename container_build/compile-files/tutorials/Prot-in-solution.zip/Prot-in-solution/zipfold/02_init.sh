#!/bin/bash -e 

CPUs=16

SysName=HEWL

top=./${SysName}.top
index=./index.ndx
prev=./min2.gro
curr=init1

## Make the tpr file for init1
singularity exec CpHMD.sif gmx grompp -f ${curr}.mdp -po ${curr}_out.mdp \
    -c ${prev} -r ${prev} -n ${index} -p ${top} \
    -pp TMP_processed.top -o ${curr}.tpr -maxwarn 1000
#
# Run initiation 1
singularity exec --nv CpHMD.sif /gromacs-gpu/bin/gmx mdrun -ntmpi 1 -ntomp $CPUs \
	    -pin on -gpu_id 0 \
	    -s ${curr}.tpr -x ${curr}.xtc -c ${curr}.gro \
	    -e ${curr}.edr -g ${curr}.log -v -nice 19
###
prev=./init1
curr=./init2
#
## Make the tpr file for init1
singularity exec CpHMD.sif gmx grompp -f ${curr}.mdp -po ${curr}_out.mdp \
    -c ${prev} -r ${prev} -n ${index} -p ${top} \
    -pp TMP_processed.top -o ${curr}.tpr -maxwarn 1000
#
# Run initiation 2
singularity exec --nv CpHMD.sif /gromacs-gpu/bin/gmx mdrun -ntmpi 1 -ntomp $CPUs \
	    -pin on -gpu_id 0 \
	    -s ${curr}.tpr -x ${curr}.xtc -c ${curr}.gro \
	    -e ${curr}.edr -g ${curr}.log -v -nice 19
#
exit 0

