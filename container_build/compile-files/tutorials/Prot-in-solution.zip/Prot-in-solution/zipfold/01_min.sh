#!/bin/sh -e 
#
#
index=index.ndx
prev=HEWL_solv.gro
curr=min1
top=HEWL.top
#
## First step with no atom constraints ##
#
singularity exec CpHMD.sif gmx grompp -f ${curr}.mdp -po ${curr}_out.mdp \
    -c ${prev} -r ${prev} -n ${index} -p ${top} \
    -pp TMP_processed.top -o ${curr}.tpr -maxwarn 1000
#
# Run initiation
singularity exec CpHMD.sif gmx mdrun  -nt 8 -s ${curr}.tpr -x ${curr}.xtc \
    -c ${curr}.gro -e ${curr}.edr -g ${curr}.log -v -nice 19

#### Second step with all-bonds atom constraints ###
prev=min1.gro
curr=min2
#
singularity exec CpHMD.sif gmx grompp -f ${curr}.mdp -po ${curr}_out.mdp \
    -c ${prev} -r ${prev} -n ${index} -p ${top} \
    -pp TMP_processed.top -o ${curr}.tpr -maxwarn 1000
#
# Run initiation
singularity exec CpHMD.sif gmx mdrun -nt 8 -s ${curr}.tpr -x ${curr}.xtc \
    -c ${curr}.gro -e ${curr}.edr -g ${curr}.log -v -nice 19
