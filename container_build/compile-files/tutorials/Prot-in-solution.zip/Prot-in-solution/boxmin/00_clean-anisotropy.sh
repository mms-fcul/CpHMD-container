#!/bin/bash

## This script removes the duplicated atoms on the pdb due to anisotropy crystal resolution
## Keeping these duplicated atoms would result in severe problems for the pdb2gmx
##
## The simple awk line is grabbing the anisotropy column (substr($0,57,4)) and checking if
## its 1. In that case it simply prints a line (there is no anisotropy.
##
## If it is different than one (anisotropy present) then it will only write the lines with
## the A molecule. Since we will be doing Molecular Dynamics, anisotropy has no meaning,
## the conformational space of the atom will be sampled with MD. 

awk '/ATOM/{if (substr($0,57,4)+0==1) {print $0} else if (substr($0,17,1)=="A") {printf"%-16s %s\n", substr($0,0,16), substr($0,18,65)}}' 3lzt.pdb > HEWL.pdb

